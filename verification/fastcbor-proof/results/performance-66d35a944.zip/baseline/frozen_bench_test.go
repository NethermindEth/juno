// This overlay preserves the frozen public operations. Corpus loading, block
// framing and warmup happen before ResetTimer. No smoke counters are used here.
package core

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"github.com/NethermindEth/juno/core/felt"
	"github.com/NethermindEth/juno/db/typed/value"
	"github.com/NethermindEth/juno/utils/cbor/fastcbor"
	"github.com/NethermindEth/juno/utils/cbor/fxamacker"
	"os"
	"reflect"
	"strings"
	"testing"
)

type gateCase struct {
	ID, Kind, Source string
	Bytes            int
	Prefix           bool
	Items            int
}
type gateUniverse struct {
	Cases   []gateCase
	Records []struct{ File, SHA256 string }
}
type gatePrefix struct {
	Indexes BlockTransactionsIndexes
	Rest    []byte
}

var gateSink any

func gateDecode[T any](data []byte) func() (any, error) {
	return func() (any, error) { var dst T; err := fastcbor.Unmarshal(data, &dst); return &dst, err }
}
func gateReference[T any](data []byte) (any, error) {
	var dst T
	err := fxamacker.Unmarshal(data, &dst)
	return &dst, err
}
func gateFactory(tb testing.TB, c gateCase, data []byte) (func() (any, error), func() (any, error)) {
	tb.Helper()
	if c.Kind == "indexes" {
		return func() (any, error) {
				var dst BlockTransactionsIndexes
				rest, err := fastcbor.UnmarshalFirst(data, &dst)
				return gatePrefix{dst, rest}, err
			},
			func() (any, error) {
				var dst BlockTransactionsIndexes
				rest, err := fxamacker.UnmarshalFirst(data, &dst)
				return gatePrefix{dst, rest}, err
			}
	}
	if strings.HasPrefix(c.Kind, "block.") {
		return gateBlockFactory(tb, strings.TrimPrefix(c.Kind, "block."), data), nil
	}
	switch c.Kind {
	case "record.header":
		return gateDecode[Header](data), func() (any, error) { return gateReference[Header](data) }
	case "record.state":
		return gateDecode[StateUpdate](data), func() (any, error) { return gateReference[StateUpdate](data) }
	case "record.receipt":
		return gateDecode[TransactionReceipt](data), func() (any, error) { return gateReference[TransactionReceipt](data) }
	case "record.class":
		return gateDecode[ClassDefinition](data), func() (any, error) { return gateReference[ClassDefinition](data) }
	case "projection.headerHash":
		return gateDecode[headerHashProjection](data), func() (any, error) { return gateReference[headerHashProjection](data) }
	case "projection.headerRoot":
		return gateDecode[headerGlobalStateRootProjection](data), func() (any, error) { return gateReference[headerGlobalStateRootProjection](data) }
	case "projection.headerCount":
		return gateDecode[headerTransactionCountProjection](data), func() (any, error) { return gateReference[headerTransactionCountProjection](data) }
	case "projection.headerTimestamp":
		return gateDecode[headerTimestampProjection](data), func() (any, error) { return gateReference[headerTimestampProjection](data) }
	case "projection.headerHashRoot":
		return gateDecode[headerHashAndStateRootProjection](data), func() (any, error) { return gateReference[headerHashAndStateRootProjection](data) }
	case "projection.receiptStatus":
		return gateDecode[receiptExecutionStatusProjection](data), func() (any, error) { return gateReference[receiptExecutionStatusProjection](data) }
	case "projection.receiptEvents":
		return gateDecode[receiptEventsProjection](data), func() (any, error) { return gateReference[receiptEventsProjection](data) }
	case "projection.transactionHash":
		return gateDecode[transactionHashProjection](data), func() (any, error) { return gateReference[transactionHashProjection](data) }
	case "record.transactionDeclare", "record.transactionDeploy", "record.transactionDeployAccount", "record.transactionInvoke", "record.transactionL1Handler":
		return gateDecode[Transaction](data), func() (any, error) { return gateReference[Transaction](data) }
	default:
		tb.Fatalf("unknown benchmark kind %s", c.Kind)
		return nil, nil
	}
}
func gateBlockFactory(tb testing.TB, kind string, data []byte) func() (any, error) {
	var indexes BlockTransactionsIndexes
	rest, err := fxamacker.UnmarshalFirst(data, &indexes)
	if err != nil {
		tb.Fatal(err)
	}
	block := BlockTransactions{Indexes: indexes, Data: rest}
	txIndex, receiptIndex := len(indexes.Transactions)/2, len(indexes.Receipts)/2
	switch kind {
	case "fullSerialized":
		return func() (any, error) {
			var dst BlockTransactions
			err := (BlockTransactionsSerializer{}).Unmarshal(data, &dst)
			return &dst, err
		}
	case "allTransactions":
		return func() (any, error) {
			var dst []Transaction
			err := BlockTransactionsAllTransactionsPartialSerializer.UnmarshalPartial(struct{}{}, data, &dst)
			return dst, err
		}
	case "allReceipts":
		return func() (any, error) {
			var dst []*TransactionReceipt
			err := BlockTransactionsAllReceiptsPartialSerializer.UnmarshalPartial(struct{}{}, data, &dst)
			return dst, err
		}
	case "allPairs":
		return func() (any, error) {
			var dst TransactionsAndReceipts
			err := BlockTransactionsAllTransactionsAndReceiptsPartialSerializer.UnmarshalPartial(struct{}{}, data, &dst)
			return &dst, err
		}
	case "allEvents":
		return func() (any, error) {
			var dst []TransactionEvents
			err := BlockTransactionsAllTransactionEventsPartialSerializer.UnmarshalPartial(struct{}{}, data, &dst)
			return dst, err
		}
	case "allHashes":
		return func() (any, error) {
			var dst []felt.Felt
			err := BlockTransactionsAllTransactionHashesPartialSerializer.UnmarshalPartial(struct{}{}, data, &dst)
			return dst, err
		}
	case "lazyAllReceipts":
		return func() (any, error) {
			return block.Receipts().All()
		}
	case "lazyAllTransactions":
		return func() (any, error) {
			return block.Transactions().All()
		}
	case "oneTransaction":
		return func() (any, error) {
			var dst Transaction
			err := BlockTransactionsTransactionPartialSerializer.UnmarshalPartial(txIndex, data, &dst)
			return dst, err
		}
	case "lazyTransaction":
		return func() (any, error) {
			return block.Transactions().Get(txIndex)
		}
	case "oneReceipt":
		return func() (any, error) {
			var dst *TransactionReceipt
			err := BlockTransactionsReceiptPartialSerializer.UnmarshalPartial(receiptIndex, data, &dst)
			return dst, err
		}
	case "lazyReceipt":
		return func() (any, error) {
			return block.Receipts().Get(receiptIndex)
		}
	case "oneStatus":
		return func() (any, error) {
			var dst TransactionExecutionStatus
			err := BlockTransactionsExecutionStatusPartialSerializer.UnmarshalPartial(receiptIndex, data, &dst)
			return &dst, err
		}
	case "onePair":
		return func() (any, error) {
			var dst TransactionAndReceipt
			err := BlockTransactionsTransactionAndReceiptPartialSerializer.UnmarshalPartial(txIndex, data, &dst)
			return &dst, err
		}
	default:
		tb.Fatalf("unclassified block kind %q", kind)
		return nil
	}
}

func gateCases(tb testing.TB) ([]gateCase, map[string]string) {
	tb.Helper()
	raw, err := os.ReadFile(os.Getenv("JUNO_CBOR_GATE_UNIVERSE"))
	if err != nil {
		tb.Fatal(err)
	}
	var u gateUniverse
	if err = json.Unmarshal(raw, &u); err != nil {
		tb.Fatal(err)
	}
	if len(u.Cases) != 185 {
		tb.Fatal("frozen case count changed")
	}
	hashes := make(map[string]string)
	for _, r := range u.Records {
		hashes[r.File] = r.SHA256
	}
	return u.Cases, hashes
}
func gateData(tb testing.TB, c gateCase, hashes map[string]string) []byte {
	tb.Helper()
	data, err := os.ReadFile(c.Source)
	if err != nil {
		tb.Fatal(err)
	}
	hash := sha256.Sum256(data)
	if hex.EncodeToString(hash[:]) != hashes[c.Source] {
		tb.Fatal("corpus hash changed", c.ID)
	}
	if c.Kind == "record.class" {
		if len(data) < 8 {
			tb.Fatal("short class frame")
		}
		data = data[8:]
	}
	if len(data) != c.Bytes {
		tb.Fatal("case size changed", c.ID)
	}
	return data
}
func TestFrozenGateOperations(t *testing.T) {
	cases, hashes := gateCases(t)
	seen := map[string]bool{}
	count := 0
	for _, c := range cases {
		if seen[c.ID] {
			t.Fatal("duplicate case", c.ID)
		}
		seen[c.ID] = true
		if c.Kind == "projection.headerBloom" {
			continue
		}
		data := gateData(t, c, hashes)
		saved := bytes.Clone(data)
		call, reference := gateFactory(t, c, data)
		got, err := call()
		if err != nil {
			t.Fatal(c.ID, err)
		}
		if reference != nil {
			want, err := reference()
			if err != nil {
				t.Fatal(err)
			}
			if !reflect.DeepEqual(got, want) {
				t.Fatal("reference mismatch", c.ID)
			}
		}
		if !bytes.Equal(saved, data) {
			t.Fatal("input changed", c.ID)
		}
		count++
	}
	if count != 179 {
		t.Fatalf("expected 179 present operations, got %d", count)
	}
}
func TestFrozenGateNoFallback(t *testing.T) {
	defer func() {
		if recover() == nil {
			t.Fatal("invalid fast input did not reject fallback")
		}
	}()
	var dst Header
	_ = value.FastCbor[Header]().Unmarshal([]byte{0x1c}, &dst)
}
func BenchmarkFrozenGate(b *testing.B) {
	cases, hashes := gateCases(b)
	for _, c := range cases {
		if selected := os.Getenv("JUNO_CBOR_GATE_CASE"); selected != "" && selected != c.ID {
			continue
		}
		if c.Kind == "projection.headerBloom" {
			continue
		}
		data := gateData(b, c, hashes)
		call, _ := gateFactory(b, c, data)
		b.Run(c.ID, func(b *testing.B) {
			if _, err := call(); err != nil {
				b.Fatal(err)
			}
			b.ReportAllocs()
			b.SetBytes(int64(len(data)))
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				dst, err := call()
				if err != nil {
					b.Fatal(err)
				}
				gateSink = dst
			}
			b.StopTimer()
		})
	}
}
